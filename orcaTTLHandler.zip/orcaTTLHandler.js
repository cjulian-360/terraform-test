'use strict';
const http = require('http');

exports.orcaTTLHandler = (event) => {
  const records = [];

  event.Records.forEach((record) => {
    if (
      record.eventName === 'REMOVE' &&
      record.dynamodb &&
      record.dynamodb.OldImage &&
      record.dynamodb.OldImage.id &&
      record.dynamodb.OldImage.exchangeName &&
      record.dynamodb.OldImage.routingKey
    ) {
      records.push({
        id: record.dynamodb.OldImage.id.S,
        exchangeName: record.dynamodb.OldImage.exchangeName.S,
        routingKey: record.dynamodb.OldImage.routingKey.S
      });
    }
  });

  if (records.length) {
    const body = JSON.stringify({ records });
    const options = {
      host: process.env.ORCA_HOST,
      path: '/status/update',
      port: 80,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body)
      }
    };
    const req = http.request(options);

    req.on(
      'error',
      /* istanbul ignore next */
      (e) => {
        console.log('request failed: ', e);
      }
    );

    req.write(body);
    req.end();
  }
};
